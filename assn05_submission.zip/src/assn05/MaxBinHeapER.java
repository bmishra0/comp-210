package assn05;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;

public class MaxBinHeapER  <V, P extends Comparable<P>> implements BinaryHeap<V, P> {

    private List<Prioritized<V,P>> _heap;

    /**
     * 1st constructor that creates an empty max heap of prioritized elements.
     */
    public MaxBinHeapER() {
        _heap = new ArrayList<>();
    }

    /**
     * @return size of heap
     */
    @Override
    public int size() {
        return _heap.size();
    }

    /**
     * TODO (Task 2A): enqueue using value and priority
     * @param value
     * @param priority
     */
    @Override
    public void enqueue(V value, P priority) {
        Prioritized<V, P> newElement = new Patient<>(value, priority);
        _heap.add(newElement);
        int i = _heap.size() - 1;
        while (i > 0) {
            int parentIndex = (i -1) / 2;
            Prioritized<V, P> parent = _heap.get(parentIndex);
            if (parent.getPriority().compareTo(newElement.getPriority()) >= 0) {
                break;
            } else {
                _heap.set(i, parent);
                _heap.set(parentIndex, newElement);
                i = parentIndex;
            }
        }
    }

    /**
     * TODO (Task 2A): enqueue (overloaded) using only value
     * @param value
     */
    public void enqueue(V value) {
        Prioritized<V, P> newElement = new Patient<>(value);
        _heap.add(newElement);
        int i = _heap.size() - 1;

        while (i > 0) {
           int parentIndex = (i - 1) / 2;
           Prioritized<V, P> parent = _heap.get(parentIndex);
            if (parent.getPriority().compareTo(newElement.getPriority()) >= 0) {
                break;
            } else {
                _heap.set(i, parent);
                _heap.set(parentIndex, newElement);
                i = parentIndex;
            }
        }
    }
// helper function
    boolean hasLeftChild (int index) {
        return (2 * index + 1 < _heap.size());
    }
    boolean hasRightChild (int index) {
        return (2 * index + 2 < _heap.size());
    }

    boolean validIndex(int index) {
      return (index >= 0 && index < _heap.size());
    }
    /**
     * TODO (Task 2A): dequeue from maxBinHeapER
     * @return element with highest priority
     */
    @Override
    public V dequeue() {
        if (_heap.isEmpty()) {
            return null;
        }
        Prioritized<V, P> root = _heap.get(0);
        Prioritized<V, P> last = _heap.remove(_heap.size() - 1);
        if (!_heap.isEmpty()) {
            _heap.set(0, last);
            bubbleDown(0);
        }
        return root.getValue();
    }

    /// helper method for bubbling down
    public void bubbleDown(int i) {
        int leftChildIndex = 2 * i + 1;
        int rightChildIndex = 2 * i + 2;
        int largest = i;
///if left child is larger
        if (hasLeftChild(i) && _heap.get(leftChildIndex).getPriority().compareTo(_heap.get(largest).getPriority()) > 0) {
            largest = leftChildIndex;
        }
        //right is larger
        if (hasRightChild(i) && _heap.get(rightChildIndex).getPriority().compareTo(_heap.get(largest).getPriority()) > 0) {
            largest = rightChildIndex;
        }
        if (largest != i) {
            Prioritized<V, P> temp = _heap.get(i);
            _heap.set(i, _heap.get(largest));
            _heap.set(largest, temp);
            bubbleDown(largest);
        }
    }

    /**
     * TODO (Task 2A): getMax
     * @return return value of element with the highest priority
     */
    @Override
    public V getMax() {
        if (!_heap.isEmpty()) {
            return _heap.get(0).getValue();
        }
    	 return null;
    }

    /**
     * TODO (Task 2B): updatePriority
     * Change the priority of the patient with the given value.
     * if newPriority is <0 then remove the element with given value
     * (In case value is not matching and existing Priority < 0, nothing is to be done.)
     * @param value
     * @param newPriority
     */
    public void updatePriority(V value, P newPriority) {
        for (int i = 0; i < _heap.size(); i++) {
            if (_heap.get(i).getValue().equals(value)) {
                if (newPriority instanceof Integer && ((Integer) newPriority) < 0) {
                    _heap.remove(i);
                    bubbleDown(i);
                } else {
                    _heap.remove(i);
                    Prioritized<V, P> newElement = new Patient<> (value, newPriority);
                    _heap.add(newElement);
                    int j = _heap.size() - 1;
                    while (j > 0) {
                        int parentIndex = (j - 1) / 2;
                        Prioritized<V, P> parent = _heap.get(parentIndex);
                        if (parent.getPriority().compareTo(newElement.getPriority()) >= 0) {
                            break;
                        } else {
                            _heap.set(j, parent);
                            _heap.set(parentIndex, newElement);
                            j = parentIndex;
                        }
                    }
                }
                return;
            }
        }
    }

    /**
     * TODO (Task 3): MaxBinHeapER
     * 2nd constructor that builds a heap given an initial array of prioritized elements.
     * @param initialEntries This is an initial ArrayList of patients
     */
    public MaxBinHeapER(Prioritized<V, P>[] initialEntries ) {
        _heap = new ArrayList<>();
        int size = initialEntries.length;
        for (int i = 0; i < size; i++) {
            _heap.add(initialEntries[i]);
        }
        for (int i = ((size - 1) /2); i >= 0; i--) {
            bubbleDown(i);
        }
    }

    /**
     * Retrieves contents of heap as an array.
     * @return array of Prioritized elements in the order stored in the heap
     */
    @Override
    public Prioritized<V, P>[] getAsArray() {
        Prioritized<V,P>[] result = (Prioritized<V, P>[]) Array.newInstance(Prioritized.class, size());
        return _heap.toArray(result);
    }
}

