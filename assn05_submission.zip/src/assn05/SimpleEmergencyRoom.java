package assn05;

import java.util.ArrayList;
import java.util.List;

public class SimpleEmergencyRoom {
    private List<Patient> _patients;

    public SimpleEmergencyRoom() {
        _patients = new ArrayList<>();
    }

    /**
     * TODO (Task 1): dequeue
     * @return return patient with the highest priority
     */
    public Patient dequeue() {
        if (_patients.size() == 0) {
            return null;
        }
        Patient patient = _patients.get(0);
       for (int i = 1; i < _patients.size(); i++) {
           Patient nextPatient = _patients.get(i);

           if (patient.getPriority().compareTo(nextPatient.getPriority()) < 0) {
               patient = nextPatient;
           }
       }
        _patients.remove(patient);
        return patient;
    }

    public <V, P> void addPatient(V value, P priority) {
        Patient patient = new Patient(value, (Integer) priority);
        _patients.add(patient);
    }

    public <V> void addPatient(V value) {
        Patient patient = new Patient(value);
        _patients.add(patient);
    }

    public List getPatients() {
        return _patients;
    }

    public int size() {
        return _patients.size();
    }

}
