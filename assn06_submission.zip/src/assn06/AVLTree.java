package assn06;

public class AVLTree<T extends Comparable<T>> implements SelfBalancingBST<T> {
    // Fields
    private T _value;
    private AVLTree<T> _left;
    private AVLTree<T> _right;
    private int _height;
    private int _size;
    
    public AVLTree() {
        _value = null;
        _left = null;
        _right = null;
        _height = -1;
        _size = 0;
    }

    /**
     * Rotates the tree left and returns
     * AVLTree root for rotated result.
     */
    private AVLTree<T> rotateLeft() {
        // You should implement left rotation and then use this
        // method as needed when fixing imbalances.
        // TODO
        AVLTree<T> rootNode = _right;
        _right = rootNode._left;
        rootNode._left = this;
        this._height = Math.max(_left.height(), _right.height()) + 1;
        rootNode._height = Math.max(rootNode._left.height(), rootNode._right.height())+1;
        _size = _left.size() + _right.size() +1;
        rootNode._size = rootNode._left.size() + rootNode._right.size() +1;
        AVLTree<T> rootNodeLeft = new AVLTree<>();
        rootNodeLeft._value = rootNode.getLeft().getValue();
        rootNodeLeft._left = (AVLTree<T>) rootNode.getLeft().getLeft();
        rootNodeLeft._right = (AVLTree<T>) rootNode.getLeft().getRight();
        rootNodeLeft._size = rootNode.getLeft().size();
        rootNodeLeft._height = rootNode.getLeft().height();

        this._value = rootNode._value;
        this._right = (AVLTree<T>) rootNode.getRight();
        this._left = (AVLTree<T>) rootNodeLeft;
        this._size = rootNode._size;
        this._height = rootNode._height;
        return this;
    }

    /**
     * Rotates the tree right and returns
     * AVLTree root for rotated result.
     */
    private AVLTree<T> rotateRight() {
        // You should implement right rotation and then use this
        // method as needed when fixing imbalances.
        // TODO
        AVLTree<T> rootNode = _left;
        _left = rootNode._right;
        rootNode._right = this;
        AVLTree<T> temp = new AVLTree<>();
        temp = this;
        this._height = Math.max(_left.height(), _right.height()) + 1;
        rootNode._height = Math.max(rootNode._left.height(), rootNode._right.height())+1;
        _size = _left.size() + _right.size() +1;
        rootNode._size = rootNode._left.size() + rootNode._right.size() +1;
        AVLTree<T> rootNodeRight = new AVLTree<>();
        rootNodeRight._value = rootNode.getRight().getValue();
        rootNodeRight._left = (AVLTree<T>) rootNode.getRight().getLeft();
        rootNodeRight._right = (AVLTree<T>) rootNode.getRight().getRight();
        rootNodeRight._size = rootNode.getRight().size();
        rootNodeRight._height = rootNode.getRight().height();
        this._value = rootNode._value;
        this._right = (AVLTree<T>) rootNodeRight;
        this._left = (AVLTree<T>) rootNode.getLeft();
        this._size = rootNode._size;
        this._height = rootNode._height;
        return this;
    }


    @Override
    public boolean isEmpty() {
        return size() == 0;
    }

    @Override
    public int height() {
        return _height;
    }

    @Override
    public int size() {
        return _size;
    }

    @Override
    public SelfBalancingBST<T> insert(T element) {
        if (_value==null) {
            _value = element;
            _left = new AVLTree<>();
            _right = new AVLTree<>();
            _height = 0;
            _size = 1;
        }
        if (element.compareTo(_value) < 0) {
            this._left = (AVLTree<T>)this._left.insert(element);

        }
        if (element.compareTo(_value) > 0) {
            this._right = (AVLTree<T>)this._right.insert(element);

        }
        _height = Math.max(_left.height(), _right.height()) + 1;
        this._size = _left.size() + _right.size() + 1;
        int balance = this._left.height() - this._right.height();
        if (balance > 1) {
            // Left-Right Case
            if (this._left._left.height() - this._left._right.height()< 0) {
                this._left = this._left.rotateLeft();
            }
            rotateRight();
        }
        else if (balance < -1) {
            if (this._right._left.height() - this._right._right.height() > 0) {
                this._right = this._right.rotateRight();
            }
            rotateLeft();
        }

        return this;
    }

    @Override
    public SelfBalancingBST<T> remove(T element) {
        if (_size==0) {
            return this;
        }
        if (!contains(element))
        {
            return this;
        }
        if (element.compareTo(_value)<0)
        {
            _left = (AVLTree<T>) _left.remove(element);
        }
        if (element.compareTo(_value)>0)
        {
            _right = (AVLTree<T>) _right.remove(element);
        }
        if (element.compareTo(_value)==0) {
            if (_right._value != null && _left._value !=null) {
                T minValue = _right.findMin();
                _right = (AVLTree<T>) _right.remove(minValue);
                _value = minValue;
            }
            else if (_right._value == null && _left._value == null) {
                return new AVLTree<>();
            }
            else if (_right._value == null) {
                return _left;
            }
            else if (_left._value == null) {
                return _right;
            }
        }

        int balance = this._left.height() - this._right.height();
        if (balance == 0||balance == -1 || balance == 1)
        {
            this._height = Math.max(_left.height(), _right.height()) + 1;
            this._size = _left.size() + _right.size()+1;

        }
        if (balance > 1) {
            if (this._left._left.height() - this._left._right.height()< 0) {
                this._left = this._left.rotateLeft();
            }
            return this.rotateRight();
        }
        else if (balance < -1) {
            if (this._right._left.height() - this._right._right.height() > 0) {
                this._right = this._right.rotateRight();
            }
            return this.rotateLeft();
        }
        return this;

    }

    @Override
    public T findMin() {
        if (isEmpty()) {
            throw new RuntimeException("Illegal operation on empty tree");
        }
        if (_left.isEmpty()){
            return _value;
        } else {
            return _left.findMin();
        }
    }

    @Override
    public T findMax() {
        if (isEmpty()) {
            throw new RuntimeException("Illegal operation on empty tree");
        }
        if (_right.isEmpty()){
            return _value;
        } else {
            return _right.findMax();
        }
    }

    @Override
    public boolean contains(T element) {
        if (isEmpty()){
            return false;
        }

        int compared = element.compareTo(_value);
        if (compared < 0){
            return _left.contains(element);
        } else if (compared > 0){
            return _right.contains(element);
        } else {
            return true;
        }

    }


    @Override
    public boolean rangeContain(T start, T end) {
        for (T i = start; i.compareTo(end) <= 0; i = increment(i)) {
            if (!contains(i)) {
                return false;
            }
        }
        return true;
    }

    private T increment(T value) {
        return (T) Integer.valueOf(((Integer) value) + 1);
    }



    @Override
    public T getValue() {
        return _value;
    }

    @Override
    public SelfBalancingBST<T> getLeft() {
        if (isEmpty()) {
            return null;
        }
        return _left;
    }

    @Override
    public SelfBalancingBST<T> getRight() {
        if (isEmpty()) {
            return null;
        }
        return _right;
    }

}

